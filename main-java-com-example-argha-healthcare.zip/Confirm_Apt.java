package com.example.argha.healthcare;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by ARGHA on 27-Jul-16.
 */
public class Confirm_Apt extends Activity {

    String user_id,doc_name,date,time_Slot_From,time_slot_to,user_F,user_L,ddd,doc_id,timeSlotid;
    TextView tv_doc_name,tv_time,tv_username,tv_date_confirm;
    Button btn_confirm;
    String url,Message;
    JSONParser jsonParser=new JSONParser();

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirm_apt);

        user_F=getIntent().getExtras().getString("User_F");
        user_L=getIntent().getExtras().getString("User_L");
        user_id=getIntent().getExtras().getString("User_ID");
        doc_name=getIntent().getExtras().getString("DoctorName");
        date=getIntent().getExtras().getString("BookingDate");
        time_Slot_From=getIntent().getExtras().getString("TimeSlotFrom");
        time_slot_to=getIntent().getExtras().getString("TimeSlotTo");

        ddd=getIntent().getExtras().getString("DDD");
        doc_id=getIntent().getExtras().getString("Doc_ID");
        timeSlotid=getIntent().getExtras().getString("TimeSlotID");
        btn_confirm=(Button)findViewById(R.id.btn_confirm);
        tv_date_confirm=(TextView)findViewById(R.id.tv_date_confirm);
        tv_doc_name=(TextView)findViewById(R.id.tv_doc_name2);
        tv_time=(TextView)findViewById(R.id.tv_Time);
        tv_username=(TextView)findViewById(R.id.tv_user_name);
        tv_time.setText(time_Slot_From+" To "+time_slot_to);
        tv_username.setText(user_F+" "+user_L);
        tv_doc_name.setText(doc_name);
        tv_date_confirm.setText(ddd);
        btn_confirm.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction()==MotionEvent.ACTION_UP){
                    btn_confirm.setBackgroundResource(R.drawable.shapr_button);
                    new Fetch_bookingNo().execute("");
                    return true;
                }
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    btn_confirm.setBackgroundResource(R.drawable.shapper_change);
                    return true;
                }
                return false;
            }
        });
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Fetch_bookingNo().execute("");

            }
        });
    }

    public class Fetch_bookingNo extends AsyncTask<String,Integer,String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try
            {
                HashMap<String, String> hashmap=new HashMap<String, String>();
                hashmap.put("doctorid",doc_id );
                hashmap.put("bookingdate",date);
                hashmap.put("userid",user_id);
                hashmap.put("timeslotid",timeSlotid);

                url="http://220.225.80.177/drbookingapp/bookingapp.asmx/BookingDr";
                JSONObject jobj_confirm=jsonParser.insertJsonFromUrl(url,"POST",hashmap);

                Message=jobj_confirm.getString("Message");

            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return null;

        }

        @Override
        protected void onPostExecute(String s) {
            Intent i5=new Intent(Confirm_Apt.this,Bye_bye.class);
            i5.putExtra("MSG",Message);
            startActivity(i5);
            super.onPostExecute(s);
        }
    }
}
