package com.example.argha.healthcare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class My_Spinner extends BaseAdapter {

    ArrayList<Doctor_department_set_get> arr1_dpt;
    Context _context;

    public My_Spinner(Context _context, ArrayList<Doctor_department_set_get> arr1_dpt) {
        this._context = _context;
        this.arr1_dpt = arr1_dpt;
    }

    @Override
    public int getCount() {
        return arr1_dpt.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder_spinner viewHolder_spinner;
        View myView=convertView;
        if (myView==null){
            LayoutInflater inf=(LayoutInflater)_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            myView=inf.inflate(R.layout.child_spinner_department,parent,false);
            viewHolder_spinner=new ViewHolder_spinner(myView);
            myView.setTag(viewHolder_spinner);
        }
        else {
                viewHolder_spinner=(ViewHolder_spinner)myView.getTag();
        }
        viewHolder_spinner.tv_departmentname.setText(arr1_dpt.get(position).getDepartment_name());


        return myView;
    }
    class ViewHolder_spinner{
        TextView tv_department_id;
        TextView tv_departmentname;
        ViewHolder_spinner(View v){
            tv_department_id=(TextView)v.findViewById(R.id.tv_department_id);
            tv_departmentname=(TextView)v.findViewById(R.id.tv_department_name);

        }
    }
}
