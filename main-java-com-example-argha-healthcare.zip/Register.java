package com.example.argha.healthcare;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Register extends Activity {

    EditText et_fname,et_lname,et_phone,et_address,et_email,et_username,et_pwd;
    Button btn_register_done;
    JSONParser jparser=new JSONParser();
    String email,password,fname,lname,address,username,phoneno;
    String suc="",Message="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        et_address=(EditText)findViewById(R.id.et_address);
        et_email=(EditText)findViewById(R.id.et_email);
        et_fname=(EditText)findViewById(R.id.et_fname);
        et_lname=(EditText)findViewById(R.id.et_lname);
        et_phone=(EditText)findViewById(R.id.et_phone);
        et_pwd=(EditText)findViewById(R.id.et_pwd);
        et_username=(EditText)findViewById(R.id.et_username);
        btn_register_done=(Button)findViewById(R.id.btn_register_done);

        btn_register_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((et_address.length()==0)|| (et_email.length()==0)||(et_fname.length()==0)||(et_lname.length()==0)||(et_phone.length()==0)||(et_pwd.length()==0)||(et_username.length()==0)){
                    Toast.makeText(Register.this,"Fill up all the blank",Toast.LENGTH_LONG).show();
                }
                else {
                    new FindItem().execute();
                }

                //Intent i2 = new Intent(Register.this, MainActivity.class);
                //startActivity(i2);
            }
        });

    }

    public class FindItem extends AsyncTask<String, Integer, String> {
        private ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            dialog=new ProgressDialog(Register.this);
            dialog.setMessage("Loading...");
            dialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try
            {
                email=et_email.getText().toString();
                password=et_pwd.getText().toString();
                fname=et_fname.getText().toString();
                lname=et_lname.getText().toString();
                address=et_address.getText().toString();
                phoneno=et_phone.getText().toString();
                username=et_username.getText().toString();

//
                HashMap<String, String> hashmap=new HashMap<String, String>();
                hashmap.put("fname",fname );
                hashmap.put("lname",lname );
                hashmap.put("username",username);
                hashmap.put("pwd",password );
                hashmap.put("address",address );
                hashmap.put("phoneno",phoneno);
                hashmap.put("email",email );


                String url="http://220.225.80.177/drbookingapp/bookingapp.asmx/UserRegistration";
                JSONObject jobj_registration_Data=jparser.insertJsonFromUrl(url,"POST",hashmap);
                suc=jobj_registration_Data.getString("Sucess");
                Message=jobj_registration_Data.getString("Message");


            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            dialog.dismiss();
            if(suc.equals("0"))
            {
                Toast.makeText(getBaseContext(), "" + Message, Toast.LENGTH_LONG).show();
            }

            else
            {
                Toast.makeText(getBaseContext(), "Registration Successfull", Toast.LENGTH_LONG).show();
            }


        }

    }
}
