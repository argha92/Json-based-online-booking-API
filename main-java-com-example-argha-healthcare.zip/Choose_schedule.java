package com.example.argha.healthcare;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Choose_schedule extends Activity {

    String user_id,sch_id,doc_name,date,doc_id,url,suc,Message,user_F,user_L,start_time,last_time,ddd;
    JSONParser jparser=new JSONParser();
    TextView tv_doc_name,tv_selected_Date,tv_selected_sch;
    ArrayList<Schedule_set_get> arr_sch=new ArrayList<Schedule_set_get>();
    ListView lv_scl_list;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_schedule);
        tv_doc_name=(TextView)findViewById(R.id.tv_doc_name1);
        lv_scl_list=(ListView)findViewById(R.id.lv_sch_list);
        tv_selected_Date=(TextView)findViewById(R.id.tv_selectdate);
        tv_selected_sch=(TextView)findViewById(R.id.tv_selectTime);
        user_id=getIntent().getExtras().getString("User_ID");
        sch_id=getIntent().getExtras().getString("Sch_ID");
        doc_name=getIntent().getExtras().getString("Doctor_name");
        final ImageButton ibtn_pop=(ImageButton)findViewById(R.id.ibtn_pop_up);
        ibtn_pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu pop_menu = new PopupMenu(Choose_schedule.this, ibtn_pop);
                pop_menu.getMenuInflater().inflate(R.menu.popup_menu, pop_menu.getMenu());
                pop_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        String strr = item.getTitle().toString();
                        if (strr.equals("Contact Us")) {
                            startActivity(new Intent(Choose_schedule.this, Contact_Us.class));
                            //Toast.makeText(Choose_doctor.this,strr,Toast.LENGTH_LONG).show();
                        }else if (strr.equals("Log Out")){
                            AppData.a=0;
                            Intent i90=new Intent(Choose_schedule.this,MainActivity.class);
                            i90.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i90);
                        }
                        return true;
                    }
                });
                pop_menu.show();
            }
        });
        date=getIntent().getExtras().getString("Date");
        ddd=getIntent().getExtras().getString("DDD");
        user_F=getIntent().getExtras().getString("User_First");
        user_L=getIntent().getExtras().getString("User_Last");
        doc_id=getIntent().getExtras().getString("Doc_ID");
        start_time=getIntent().getExtras().getString("StatTime");
        last_time=getIntent().getExtras().getString("EndTime");
        tv_doc_name.setText(doc_name);
        tv_selected_Date.setText(ddd);
        //Toast.makeText(Choose_schedule.this,""+date+user_id+user_L+user_L,Toast.LENGTH_LONG);
        tv_selected_sch.setText("From : "+start_time+"  To : "+last_time);
        new Get_scheduleList().execute();
    }


    public class Get_scheduleList extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try
            {
                HashMap<String, String> hashmap=new HashMap<String, String>();
                hashmap.put("scheduleid",sch_id );
                hashmap.put("date",date);
                hashmap.put("userid",user_id);

                url="http://220.225.80.177/drbookingapp/bookingapp.asmx/GetAppointmentSchedule";
                JSONObject jobj_GetDoctor_Data=jparser.insertJsonFromUrl(url,"POST",hashmap);
                suc=jobj_GetDoctor_Data.getString("Sucess");

                if (suc.equals("1")){
                    JSONArray jarr=jobj_GetDoctor_Data.getJSONArray("availableschedule");
                    for (int i=0;i<jarr.length();i++){
                        JSONObject jobj1=jarr.getJSONObject(i);
                        Schedule_set_get s1=new Schedule_set_get();
                        s1.setTimeslot_id(jobj1.getString("timeslotid"));
                        s1.setStatus(jobj1.getString("status"));
                        s1.setSlotfrom(jobj1.getString("slotfrom"));
                        s1.setSlotto(jobj1.getString("slotto"));
                        arr_sch.add(s1);
                    }
                }
                Message=jobj_GetDoctor_Data.getString("Message");

            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return suc;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (suc.equals("0")){
                Toast.makeText(Choose_schedule.this,"No schedule available",Toast.LENGTH_LONG).show();
            }
            else {
                lv_scl_list.setAdapter(new Schedule_listView(arr_sch, Choose_schedule.this));
                lv_scl_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String yah = arr_sch.get(position).getStatus();
                        if (yah.equals("Y")) {
                            Intent i7 = new Intent(Choose_schedule.this, Confirm_Apt.class);
                            i7.putExtra("User_ID", user_id);
                            i7.putExtra("DoctorName", doc_name);
                            i7.putExtra("TimeSlotFrom", arr_sch.get(position).getSlotfrom());
                            i7.putExtra("TimeSlotTo", arr_sch.get(position).getSlotto());
                            i7.putExtra("BookingDate", date);
                            i7.putExtra("User_F", user_F);
                            i7.putExtra("User_L", user_L);
                            i7.putExtra("DDD", ddd);
                            i7.putExtra("Doc_ID", doc_id);
                            i7.putExtra("TimeSlotID", arr_sch.get(position).getTimeslot_id());
                            startActivity(i7);
                        } else if (yah.equals("N")) {
                            
                            //Toast.makeText(Choose_schedule.this,"This time slot id already booked",Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }

        }
    }
}
