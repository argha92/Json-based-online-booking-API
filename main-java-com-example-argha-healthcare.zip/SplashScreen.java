package com.example.argha.healthcare;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;


/**
 * Created by ARGHA on 27-Jul-16.
 */
public class SplashScreen extends Activity {

    String u_name,u_id,u_lname;
    int cond;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    Intent i_login;
    private static int SPLASH_TIME_OUT=4000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);


        SharedPreferences sf=getSharedPreferences("PREF", Context.MODE_PRIVATE);
        u_name=sf.getString("User_F","");
        u_id=sf.getString("UserId","");
        u_lname=sf.getString("User_L","");
        cond=AppData.a;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (cond==0) {
                    AppData.a=1;
                    Intent in1 = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(in1);
                    finish();
                }
                else if (cond==1){
                    Intent in2=new Intent(SplashScreen.this,Choose_doctor.class);
                    in2.putExtra("User_ID",u_id);
                    in2.putExtra("User_L", u_lname);
                    in2.putExtra("User_F",u_name);
                    startActivity(in2);
                    finish();
                }
            }
        },SPLASH_TIME_OUT);
    }
}
