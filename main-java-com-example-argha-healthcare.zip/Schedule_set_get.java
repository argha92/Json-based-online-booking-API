package com.example.argha.healthcare;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Schedule_set_get {
    String timeslot_id,status,slotfrom,slotto;

    public String getTimeslot_id() {
        return timeslot_id;
    }

    public void setTimeslot_id(String timeslot_id) {
        this.timeslot_id = timeslot_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSlotfrom() {
        return slotfrom;
    }

    public void setSlotfrom(String slotfrom) {
        this.slotfrom = slotfrom;
    }

    public String getSlotto() {
        return slotto;
    }

    public void setSlotto(String slotto) {
        this.slotto = slotto;
    }
}
