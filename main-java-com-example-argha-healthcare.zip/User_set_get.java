package com.example.argha.healthcare;

/**
 * Created by ARGHA on 27-Jul-16.
 */
public class User_set_get {

    String user_id,Lname,Fname;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }
}
