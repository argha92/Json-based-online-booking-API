package com.example.argha.healthcare;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Doctor_department_set_get {

    String departnemt_id,department_name;

    public String getDepartnemt_id() {
        return departnemt_id;
    }

    public void setDepartnemt_id(String departnemt_id) {
        this.departnemt_id = departnemt_id;
    }

    public String getDepartment_name() {
        return department_name;
    }

    public void setDepartment_name(String department_name) {
        this.department_name = department_name;
    }
}
