package com.example.argha.healthcare;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Doctor_deatils {

    String day_of_apt;

    public String getDay_of_apt() {
        return day_of_apt;
    }

    public void setDay_of_apt(String day_of_apt) {
        this.day_of_apt = day_of_apt;
    }
}
