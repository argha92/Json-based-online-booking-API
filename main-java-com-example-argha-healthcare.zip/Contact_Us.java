package com.example.argha.healthcare;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Contact_Us extends Activity {

    Button btn_cu_exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_us);
        btn_cu_exit=(Button)findViewById(R.id.btn_cu_exit);

        btn_cu_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
