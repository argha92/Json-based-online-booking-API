package com.example.argha.healthcare;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;


public class Choose_doctor extends Activity {

    Spinner sp_choose_department;
    ArrayList<Doctor_department_set_get> arr_dpt=null;
    ArrayList<Doctor_Name_set> arr_doc;
    int y,m,d,x=0;
    ListView lv_choose_doctor;
    JSONParser jparser=new JSONParser();
    String position_spinner,url,user_id,user_F,user_L;
    String dpt_id,apt_date,date1,suc="",Message="",ddd;
    ImageButton ibtn_calendar,ibtn_pop_up;
    Button btn_search;
    TextView tv_date;

    @Override
    public void onBackPressed() {
        finish();
        System.runFinalizersOnExit(true);
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_doctor);
        sp_choose_department=(Spinner)findViewById(R.id.sp_doctor_dpt);
        ibtn_calendar=(ImageButton)findViewById(R.id.ibtn_calendar);
        btn_search=(Button)findViewById(R.id.btn_search);
        ibtn_pop_up=(ImageButton)findViewById(R.id.ibtn_pop_up);
        tv_date=(TextView)findViewById(R.id.tv_date);
        lv_choose_doctor=(ListView)findViewById(R.id.lv_name_of_doctor);

        user_id=getIntent().getExtras().getString("User_ID");
        user_F=getIntent().getExtras().getString("User_F");
        user_L=getIntent().getExtras().getString("User_L");


        Calendar c=Calendar.getInstance();
        y=c.get(Calendar.YEAR);
        m=c.get(Calendar.MONTH);
        d=c.get(Calendar.DAY_OF_MONTH);
        String date=""+d+"."+(m+1)+"."+y;
        tv_date.setText(date);

        ibtn_pop_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu pop_menu = new PopupMenu(Choose_doctor.this, ibtn_pop_up);
                pop_menu.getMenuInflater().inflate(R.menu.popup_menu, pop_menu.getMenu());
                pop_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        String strr = item.getTitle().toString();
                        if (strr.equals("Contact Us")) {
                            startActivity(new Intent(Choose_doctor.this, Contact_Us.class));
                            //Toast.makeText(Choose_doctor.this,strr,Toast.LENGTH_LONG).show();
                        } else if (strr.equals("Log Out")){
                            AppData.a=0;
                            //AppData.u_id=null;
                            Intent i90=new Intent(Choose_doctor.this,MainActivity.class);
                            i90.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i90);
                        }
                        return true;
                    }
                });
                pop_menu.show();
            }
        });

        ibtn_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(1);
            }
        });


        new Find_dpt().execute("");
        sp_choose_department.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                position_spinner = arr_dpt.get(position).getDepartnemt_id();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn_search.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction()==MotionEvent.ACTION_UP){
                    btn_search.setBackgroundResource(R.drawable.shapr_button);
                    new Get_Doctor().execute();
                    return true;
                }
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    btn_search.setBackgroundResource(R.drawable.shapper_change);
                    return true;
                }

                return false;
            }
        });

    }

    public class Get_Doctor extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try
            {
                dpt_id=position_spinner;
                apt_date=date1;


                HashMap<String, String> hashmap=new HashMap<String, String>();
                hashmap.put("departmentid",dpt_id );
                hashmap.put("bookingdate",apt_date);

                url="http://220.225.80.177/drbookingapp/bookingapp.asmx/GetDoctor";
                JSONObject jobj_GetDoctor_Data=jparser.insertJsonFromUrl(url,"POST",hashmap);
                suc=jobj_GetDoctor_Data.getString("Sucess");
                //arr_doc=new ArrayList<Doctor_Name_set>();
                if (suc.equals("1")){
                    arr_doc=new ArrayList<Doctor_Name_set>();
                    JSONArray jarr=jobj_GetDoctor_Data.getJSONArray("DoctorSchedule");
                    x=jarr.length();
                    for (int i=0;i<jarr.length();i++){
                        JSONObject jobj1=jarr.getJSONObject(i);
                        Doctor_Name_set doc1=new Doctor_Name_set();
                        doc1.setSchedule_id(jobj1.getString("scheduleid"));
                        doc1.setDoc_id(jobj1.getString("doctorid"));
                        JSONObject jobj2=jobj1.getJSONObject("doctorde");
                        doc1.setName(jobj2.getString("doctorname"));
                        JSONObject jobj3=jobj1.getJSONObject("schdet");
                        doc1.setStartTime(jobj3.getString("starttime"));
                        doc1.setEndTime(jobj3.getString("endtime"));
                        arr_doc.add(doc1);

                    }
                }
                Message=jobj_GetDoctor_Data.getString("Message");

            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if (suc.equals("0")){

                Toast.makeText(Choose_doctor.this, "No doctor is available Today", Toast.LENGTH_LONG).show();
            }
            else {
                if(x==0){
                    Toast.makeText(Choose_doctor.this,"No doctor is avalable Today",Toast.LENGTH_LONG).show();
                }else{
                    lv_choose_doctor.setAdapter(new My_Doc_ListView(arr_doc, Choose_doctor.this));
                    lv_choose_doctor.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent i6 = new Intent(Choose_doctor.this, Choose_schedule.class);
                            i6.putExtra("Sch_ID", arr_doc.get(position).getSchedule_id());
                            i6.putExtra("Date", date1);
                            i6.putExtra("Doctor_name", arr_doc.get(position).getName());
                            i6.putExtra("Doc_ID", arr_doc.get(position).getDoc_id());
                            i6.putExtra("User_ID", user_id);
                            i6.putExtra("User_First", user_F);
                            i6.putExtra("User_Last", user_L);
                            i6.putExtra("StatTime", arr_doc.get(position).getStartTime());
                            i6.putExtra("EndTime", arr_doc.get(position).getEndTime());
                            i6.putExtra("DDD", ddd);
                            startActivity(i6);
                        }
                    });
                }
            }
            super.onPostExecute(s);
        }
    }



    @Override
    protected Dialog onCreateDialog(int id) {
        DatePickerDialog dp=new DatePickerDialog(Choose_doctor.this,obj,y,m,d);
        return dp;
    }
    DatePickerDialog.OnDateSetListener obj=new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            tv_date.setText(""+dayOfMonth+"."+(monthOfYear+1)+"."+year);
            date1=""+(monthOfYear+1)+"."+dayOfMonth+"."+year;
            ddd=""+dayOfMonth+"."+(monthOfYear+1)+"."+year;
        }
    };







    public class Find_dpt extends AsyncTask<String,Integer,String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String url="http://220.225.80.177/drbookingapp/bookingapp.asmx/GetDepartment";
            String suc="";
            JSONParser jpar_Find_dpt=new JSONParser();
            JSONObject jobj1=jpar_Find_dpt.getJsonFromURL(url);

            try {
                arr_dpt=new ArrayList<Doctor_department_set_get>();
                suc=jobj1.getString("Sucess");
                if (suc.equals("1")){
                    JSONArray jarr1=jobj1.getJSONArray("DepartmentDetails");
                    for (int i=0;i<jarr1.length();i++){
                        JSONObject jobj2=jarr1.getJSONObject(i);
                        Doctor_department_set_get dpt1=new Doctor_department_set_get();
                        dpt1.setDepartment_name(jobj2.getString("departmentname"));
                        dpt1.setDepartnemt_id(jobj2.getString("departmentid"));
                        arr_dpt.add(dpt1);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return suc;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            sp_choose_department.setAdapter(new My_Spinner(Choose_doctor.this,arr_dpt));
        }
    }

}
