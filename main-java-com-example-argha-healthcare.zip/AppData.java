package com.example.argha.healthcare;

/**
 * Created by ARGHA on 27-Jul-16.
 */
public class AppData {
    public static int a=0;
}
