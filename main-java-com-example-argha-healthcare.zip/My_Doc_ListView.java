package com.example.argha.healthcare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class My_Doc_ListView extends BaseAdapter {

    ArrayList<Doctor_Name_set> arr_doc;
    Context _context;

    public My_Doc_ListView(ArrayList<Doctor_Name_set> arr_doc, Context _context) {
        this.arr_doc = arr_doc;
        this._context = _context;
    }

    @Override
    public int getCount() {
        return arr_doc.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder myViewHolder;
        View MyView = convertView;
        if (MyView == null) {
            LayoutInflater inf = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            MyView = inf.inflate(R.layout.child_list_doc, parent, false);
            myViewHolder = new ViewHolder(MyView);
            MyView.setTag(myViewHolder);
        } else {
            myViewHolder = (ViewHolder) MyView.getTag();
        }
        myViewHolder.tv_doc_name.setText(arr_doc.get(position).getName());
        return MyView;
    }


    class ViewHolder {

        TextView tv_sch_id, tv_doc_id, tv_doc_name;

        ViewHolder(View v) {
            tv_doc_id = (TextView) v.findViewById(R.id.tv_doc_id);
            tv_doc_name = (TextView) v.findViewById(R.id.tv_doc_name);
            tv_sch_id = (TextView) v.findViewById(R.id.tv_sch_id);
        }
    }
}

