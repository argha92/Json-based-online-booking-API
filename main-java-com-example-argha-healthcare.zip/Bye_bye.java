package com.example.argha.healthcare;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

/**
 * Created by ARGHA on 27-Jul-16.
 */
public class Bye_bye extends Activity {

    TextView tv_confirm;
    Button btn_home;
    ImageButton ibtn_popUp4;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bye_bye);
        btn_home=(Button)findViewById(R.id.btn_home);
        ibtn_popUp4=(ImageButton)findViewById(R.id.ibtn_pop_up4);
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii1=new Intent(Bye_bye.this,MainActivity.class);
                ii1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(ii1);


            }
        });

        tv_confirm=(TextView)findViewById(R.id.tv_confirm);
        String msg=getIntent().getExtras().getString("MSG");
        tv_confirm.setText(msg);
        ibtn_popUp4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu pop_menu = new PopupMenu(Bye_bye.this, ibtn_popUp4);
                pop_menu.getMenuInflater().inflate(R.menu.popup_menu, pop_menu.getMenu());
                pop_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        String strr = item.getTitle().toString();
                        if (strr.equals("Contact Us")) {
                            startActivity(new Intent(Bye_bye.this, Contact_Us.class));
                            //Toast.makeText(Choose_doctor.this,strr,Toast.LENGTH_LONG).show();
                        } else if (strr.equals("Log Out")) {
                            AppData.a = 0;
                            Intent i90 = new Intent(Bye_bye.this, MainActivity.class);
                            i90.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i90);
                        }
                        return true;
                    }
                });
                pop_menu.show();
            }
        });

    }
}
