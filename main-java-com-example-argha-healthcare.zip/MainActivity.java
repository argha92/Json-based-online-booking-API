package com.example.argha.healthcare;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class MainActivity extends Activity {

    EditText et_username,et_password;
    Button btn_login,btn_register,btn_exit;
    CheckBox ch_box1;
    String password,username,suc="",Message="",user_id,user_l,user_f;
    JSONParser jparser=new JSONParser();
    ArrayList<User_set_get> arr_user=new ArrayList<User_set_get>();

    @Override
    public void onBackPressed() {
        finish();
        System.runFinalizersOnExit(true);
        //super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ch_box1=(CheckBox)findViewById(R.id.activity_main_chkBox);
        et_password=(EditText)findViewById(R.id.et_password);
        et_username=(EditText)findViewById(R.id.et_username);
        btn_login=(Button)findViewById(R.id.btn_login);
        btn_exit=(Button)findViewById(R.id.btn_exit);
        btn_register=(Button)findViewById(R.id.btn_register);

        SharedPreferences sf=getSharedPreferences("PREF", Context.MODE_PRIVATE);
        String u_name=sf.getString("UserName", "");
        String u_pass=sf.getString("Password","");
        et_password.setText(u_pass);
        et_username.setText(u_name);

        btn_register.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_register.setTextSize(16);
                    Intent i1 = new Intent(MainActivity.this, Register.class);
                    startActivity(i1);
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_register.setBackgroundResource(R.drawable.shapper_change);
                    return true;
                }
                return false;
            }
        });

        /*btn_exit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                *//*if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_login.setBackgroundResource(R.drawable.shapr_button);
                    //finish();
                    System.runFinalizersOnExit(true);
                    System.exit(0);
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_login.setBackgroundResource(R.drawable.shapper_change);
                    return true;
                }*//*

                System.exit(0);

                return false;
            }
        });*/

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

                System.exit(0);
            }
        });

        btn_login.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_login.setBackgroundResource(R.drawable.shapr_button);

                    new Get_success().execute();
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_login.setBackgroundResource(R.drawable.shapper_change);
                    return true;
                }

                return false;
            }
        });

    }


    private String LoadPreferences() {
        // TODO Auto-generated method stub
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        String strSavedMem1 = sharedPreferences.getString("UserName", "");
        String strSavedMem2 = sharedPreferences.getString("Password", "");
        et_username.setText(strSavedMem1);
        et_password.setText(strSavedMem2);
        return null;
    }



    protected void SavePreferences(String key, String value) {
        // TODO Auto-generated method stub
        SharedPreferences sharedPreferences = getSharedPreferences("PREF", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }


    public class Get_success extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try
            {
                password=et_password.getText().toString();
                username=et_username.getText().toString();

//
                HashMap<String, String> hashmap=new HashMap<String, String>();
                hashmap.put("username",username);
                hashmap.put("pwd",password );


                String url="http://220.225.80.177/drbookingapp/bookingapp.asmx/UserLogin";
                JSONObject jobj_login=jparser.insertJsonFromUrl(url,"POST",hashmap);
                suc=jobj_login.getString("Sucess");
                if (suc.equals("1")){
                    JSONObject jobjj=jobj_login.getJSONObject("UserDetails");
                    User_set_get u1=new User_set_get();
                    u1.setUser_id(jobjj.getString("userid"));
                    u1.setFname(jobjj.getString("fname"));
                    u1.setLname(jobjj.getString("lname"));
                    arr_user.add(u1);
                }


                Message=jobj_login.getString("Message");


            }
            catch(Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //dialog.dismiss();
            if(suc.equals("0"))
            {
                Toast.makeText(getBaseContext(), "" + Message, Toast.LENGTH_LONG).show();
            }

            else
            {
                int pos=0;
                user_id=arr_user.get(pos).getUser_id().toString();
                user_f=arr_user.get(pos).getFname().toString();
                user_l=arr_user.get(pos).getLname().toString();

                if(ch_box1.isChecked()==true){
                    SavePreferences("UserName", et_username.getText().toString());
                    SavePreferences("Password", et_password.getText().toString());
                    SavePreferences("UserId", user_id);
                    SavePreferences("User_L",user_l);
                    SavePreferences("User_F",user_f);
                    LoadPreferences();
                }
                else {
                    LoadPreferences();
                }
                Intent i3=new Intent(MainActivity.this,Choose_doctor.class);
                i3.putExtra("User_ID",user_id);
                i3.putExtra("User_F",user_f);
                i3.putExtra("User_L",user_l);
                startActivity(i3);
            }
        }
    }
}