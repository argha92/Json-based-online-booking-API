package com.example.argha.healthcare;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ARGHA on 27-Jul-16.
 */

public class Schedule_listView extends BaseAdapter {

    ArrayList<Schedule_set_get> arr_sch;
    Context _context;

    public Schedule_listView(ArrayList<Schedule_set_get> arr_sch, Context _context) {
        this.arr_sch = arr_sch;
        this._context = _context;
    }

    @Override
    public int getCount() {
        return arr_sch.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View_Schedule myView_Sch;
        if (convertView==null){
            LayoutInflater inf=(LayoutInflater)_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inf.inflate(R.layout.child_schdule,parent,false);
            myView_Sch=new View_Schedule(convertView);
            convertView.setTag(myView_Sch);
        }
        else {
            myView_Sch=(View_Schedule)convertView.getTag();
        }
        String yah=arr_sch.get(position).getStatus();

        if (yah.equals("Y")){
            myView_Sch.tv_slotto.setTextColor(Color.parseColor("#FFFFFF"));
            myView_Sch.tv_to.setTextColor(Color.parseColor("#FFFFFF"));
            myView_Sch.tv_slotfrom.setTextColor(Color.parseColor("#FFFFFF"));
            }
        else if (yah.equals("N")){
            myView_Sch.tv_slotfrom.setTextColor(Color.parseColor("#6F000000"));
            myView_Sch.tv_to.setTextColor(Color.parseColor("#6F000000"));
            myView_Sch.tv_slotto.setTextColor(Color.parseColor("#6F000000"));
            }
        myView_Sch.tv_slotfrom.setText("  "+arr_sch.get(position).getSlotfrom()+"  ");
        myView_Sch.tv_to.setText("to  ");
        myView_Sch.tv_slotto.setText(arr_sch.get(position).getSlotto());
        return convertView;
    }

    public  class View_Schedule{
        TextView tv_slotid,tv_slotfrom,tv_slotto,tv_status,tv_to;
        View_Schedule(View v){
            tv_slotfrom=(TextView)v.findViewById(R.id.tv_slotFrom);
            tv_slotid=(TextView)v.findViewById(R.id.tv_slotid);
            tv_slotto=(TextView)v.findViewById(R.id.tv_slotto);
            tv_status=(TextView)v.findViewById(R.id.tv_status);
            tv_to=(TextView)v.findViewById(R.id.tv_to);
        }
    }
}
